                 ##########################################
                 # Escape From Colditz - Analysis Archive #
                 ##########################################

This archive contains the files used for the Reverse Engineering of the game.
This is of course provided AS IS, for the very few souls who might be as 
interested in this stuff as I am...

o game_dump.bin
  Amiga (UAE) memory dump used to disassemble the original game.

o game_dump.png
  State of the screen when the game was dumped.

o game_dump.7z
  7zip compressed commented HTML disassembly listing, as produced by IDA Pro.
  For those who don't have access to IDA but still want to look at the 
  disassembly. Note that the uncompressed HTML file is pretty big and requires
  a lot of available memory to load in your browser
  
o game_dump.idc
  Commented disassembly in IDA Pro 5.5 IDC format
  If you have IDA Pro, just load this IDC against the memory dump to have 
  complete interactive access to the actual disassembly!
  
o SKR_COLD.html
  Commented disassembly for our reverse engineering of the ByteKiller 1.3
  compression (which is used to compress COLDITZ-LOADER)
  
o memory map.txt
  Memory Map for the commented disassembly + additional notes

o COMPRESSED_MAPS.txt, COLDITZ_ROOM_MAPS.txt
  Room maps, tranlated to cells data

o COLDITZ_CELLS (with_index).png
  Cells data for the maps above
  
  
          #######################################################
          # Aperture Software: We do what we do because we can! #
          #######################################################
